package com.candyore.backend.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.candyore.backend.entity.Register;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author CandyOre
 * @since 2022-12-25
 */
@Mapper
public interface RegisterMapper extends BaseMapper<Register> {

    IPage pageCC(IPage<Register> page, @Param(Constants.WRAPPER) Wrapper wrapper);
}
