package com.candyore.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.candyore.backend.entity.Transfer;
import com.candyore.backend.mapper.TransferMapper;
import com.candyore.backend.service.TransferService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class TransferServiceImpl extends ServiceImpl<TransferMapper, Transfer> implements TransferService {
    @Resource
    private TransferMapper transferMapper;
    @Override
    public IPage pageCC(IPage<Transfer> page, Wrapper wrapper) {
        return transferMapper.pageCC(page,wrapper);
    }
}
