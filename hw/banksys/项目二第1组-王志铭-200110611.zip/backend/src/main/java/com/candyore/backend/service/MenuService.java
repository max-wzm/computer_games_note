package com.candyore.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.candyore.backend.entity.Menu;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CandyOre
 * @since 2023-01-11
 */
public interface MenuService extends IService<Menu> {

}
