package com.candyore.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CandyOreApplication {

    public static void main(String[] args) {
        SpringApplication.run(CandyOreApplication.class, args);
    }

}
