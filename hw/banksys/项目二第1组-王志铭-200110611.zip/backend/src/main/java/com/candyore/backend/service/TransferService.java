package com.candyore.backend.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.candyore.backend.entity.Transfer;

public interface TransferService extends IService<Transfer> {
    IPage pageCC(IPage<Transfer> page, Wrapper wrapper);
}
