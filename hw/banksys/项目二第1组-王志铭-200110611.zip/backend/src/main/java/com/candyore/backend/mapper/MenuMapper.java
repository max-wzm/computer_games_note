package com.candyore.backend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.candyore.backend.entity.Menu;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author CandyOre
 * @since 2023-01-11
 */
@Mapper
public interface MenuMapper extends BaseMapper<Menu> {

}
