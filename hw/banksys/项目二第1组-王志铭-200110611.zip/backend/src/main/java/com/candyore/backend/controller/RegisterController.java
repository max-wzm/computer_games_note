package com.candyore.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.candyore.backend.common.QueryPageParam;
import com.candyore.backend.common.Result;
import com.candyore.backend.entity.Menu;
import com.candyore.backend.entity.Register;
import com.candyore.backend.service.MenuService;
import com.candyore.backend.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author CandyOre
 * @since 2022-12-25
 */
@RestController
@RequestMapping("/register")
public class RegisterController {

    @Autowired
    private RegisterService registerService;

    @Autowired
    private MenuService menuService;

    @GetMapping("/findByAccount")
    public Result findByAccount(@RequestParam String account){
        List list = registerService.lambdaQuery().eq(Register::getAccount,account).list();
        return list.size()>0?Result.suc(list):Result.fail();
    }

    @GetMapping("/findById")
    public Result findById(@RequestParam String rid){
        System.out.println("find by id" + rid);
        List list = registerService.lambdaQuery().eq(Register::getRid,rid).list();
        return list.size()>0?Result.suc(list):Result.fail();
    }

    @PostMapping("/login")
    public Result login(@RequestBody Register register){
        List list = registerService.lambdaQuery()
                .eq(Register::getAccount,register.getAccount())
                .eq(Register::getPassword,register.getPassword()).list();

        if(list.size()>0){
            Register user1 = (Register) list.get(0);
            List menuList = menuService.lambdaQuery().like(Menu::getMenuright,user1.getType() ? "1" : "0").list();

            HashMap res = new HashMap();
            res.put("user", user1);
            res.put("menu", menuList);
            System.out.println(res);
            return Result.suc(res);
        }
        return Result.fail();
    }

    @PostMapping("/save")
    public Result save(@RequestBody Register register){
        System.out.println("save" + register);
        return registerService.save(register)?Result.suc():Result.fail();
    }
    @PostMapping("/update")
    public Result update(@RequestBody Register register){
        System.out.println("update" + register);
        UpdateWrapper<Register> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("rid", register.getRid());
        return registerService.update(register, updateWrapper)?Result.suc():Result.fail();
    }
    @GetMapping("/del")
    public Result del(@RequestParam String id){
        System.out.println("del" + id);
        QueryWrapper<Register> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("rid", BigDecimal.valueOf(Integer.parseInt(id)));
        return registerService.remove(queryWrapper)?Result.suc():Result.fail();
    }

    @PostMapping("/listPageC1")
    public Result listPageC1(@RequestBody QueryPageParam query){
        System.out.println("list" + query);
        HashMap param = query.getParam();
        String name = (String)param.get("name");
        String sex = (String)param.get("sex"); // 女"0"
        String roleId = (String)param.get("roleId"); // 管理员"1"普通"0"

        Page<Register> page = new Page();
        page.setCurrent(query.getPageNum());
        page.setSize(query.getPageSize());

        LambdaQueryWrapper<Register> lambdaQueryWrapper = new LambdaQueryWrapper();
        if(StringUtils.isNotBlank(name) && !"null".equals(name)){
            lambdaQueryWrapper.like(Register::getName,name);
        }
        if(StringUtils.isNotBlank(sex)){
            lambdaQueryWrapper.eq(Register::getGender, BigDecimal.valueOf(Integer.parseInt(sex)));
        }
        if(StringUtils.isNotBlank(roleId)){
            lambdaQueryWrapper.eq(Register::getType,roleId.equals("1"));
        }

        IPage result = registerService.pageCC(page,lambdaQueryWrapper);

        return Result.suc(result.getRecords(),result.getTotal());
    }
}
