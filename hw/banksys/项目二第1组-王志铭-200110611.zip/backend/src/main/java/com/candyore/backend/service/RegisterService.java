package com.candyore.backend.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.candyore.backend.entity.Register;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CandyOre
 * @since 2022-12-25
 */
public interface RegisterService extends IService<Register> {
    IPage pageCC(IPage<Register> page, Wrapper wrapper);
}
