package com.candyore.backend.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.candyore.backend.common.QueryPageParam;
import com.candyore.backend.common.Result;
import com.candyore.backend.entity.Register;
import com.candyore.backend.entity.Transfer;
import com.candyore.backend.service.RegisterService;
import com.candyore.backend.service.TransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/transfer")
public class TransferController {

    @Autowired
    private TransferService transferService;

    @Autowired
    private RegisterService registerService;

    @GetMapping("/testAmount")
    public Result testAmount(@RequestParam String rid, @RequestParam Integer amount) {
        System.out.println("test amount " + rid + " " + amount);
        List list = registerService.lambdaQuery().eq(Register::getRid,rid).list();
        if (list.size() == 0) {
            return Result.fail();
        }
        Register register = (Register) list.get(0);
        System.out.println(register);
        if (register.getAmount() < amount) {
            return Result.fail();
        } else {
            return Result.suc(list);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/save")
    public Result save(@RequestBody Transfer transfer){
        System.out.println("save" + transfer);
        try {
            transferService.save(transfer);

            List list = registerService.lambdaQuery().eq(Register::getRid,transfer.getRid()).list();
            if (list.size() == 0) {
                throw new RuntimeException("no rid1");
            }
            Register register1 = (Register) list.get(0);
            System.out.println(register1);

            list = registerService.lambdaQuery().eq(Register::getRid,transfer.getRid2()).list();
            if (list.size() == 0) {
                throw new RuntimeException("no rid2");
            }
            Register register2 = (Register) list.get(0);
            System.out.println(register2);

            if (register1.getAmount() < transfer.getAmount()) {
                throw new RuntimeException("amount too large");
            }

            register1.setAmount(register1.getAmount() - transfer.getAmount());
            register2.setAmount(register2.getAmount() + transfer.getAmount());

            UpdateWrapper<Register> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("rid", register1.getRid());
            registerService.update(register1, updateWrapper);

            updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("rid", register2.getRid());
            registerService.update(register2, updateWrapper);
        } catch (Exception e) {
            e.printStackTrace();
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return Result.fail();
        }
        return Result.suc();
    }

    @PostMapping("/listPageC1")
    public Result listPageC1(@RequestBody QueryPageParam query){
        System.out.println("list transfer" + query);
        HashMap param = query.getParam();
        String rid = (String) param.get("rid");
        String rid2 = (String) param.get("rid2");
        String myid = (String) param.get("myid");

        Page<Transfer> page = new Page();
        page.setCurrent(query.getPageNum());
        page.setSize(query.getPageSize());

        LambdaQueryWrapper<Transfer> lambdaQueryWrapper = new LambdaQueryWrapper();
        boolean flag1 = true, flag2 = true;
        if (StringUtils.isNotBlank(rid) && !"null".equals(rid)) {
            lambdaQueryWrapper.eq(Transfer::getRid, rid);
            flag1 = false;
        }
        if (StringUtils.isNotBlank(rid2) && !"null".equals(rid2)) {
            lambdaQueryWrapper.eq(Transfer::getRid2, rid2);
            flag2 = false;
        }
        if (StringUtils.isNotBlank(myid) && !"null".equals(myid)) {
            if (flag1 && flag2) {
                lambdaQueryWrapper.eq(Transfer::getRid, myid)
                        .or().eq(Transfer::getRid2, myid);
            } else if (flag1) {
                lambdaQueryWrapper.eq(Transfer::getRid, myid);
            } else {
                lambdaQueryWrapper.eq(Transfer::getRid2, myid);
            }
        }

//        System.out.println(lambdaQueryWrapper.getTargetSql());

        IPage result = transferService.pageCC(page,lambdaQueryWrapper);

//        System.out.println(result.getRecords());

        return Result.suc(result.getRecords(),result.getTotal());
    }
}
