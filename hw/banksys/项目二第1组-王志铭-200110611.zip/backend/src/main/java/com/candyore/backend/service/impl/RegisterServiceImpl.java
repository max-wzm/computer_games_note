package com.candyore.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.candyore.backend.entity.Register;
import com.candyore.backend.mapper.RegisterMapper;
import com.candyore.backend.service.RegisterService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CandyOre
 * @since 2022-12-25
 */
@Service
public class RegisterServiceImpl extends ServiceImpl<RegisterMapper, Register> implements RegisterService {
    @Resource
    private RegisterMapper registerMapper;
    @Override
    public IPage pageCC(IPage<Register> page, Wrapper wrapper) {
        return registerMapper.pageCC(page,wrapper);
    }
}
