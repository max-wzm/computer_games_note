package com.candyore.backend.entity;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author CandyOre
 * @since 2022-12-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Register对象", description="")
public class Register implements Serializable {

    private static final long serialVersionUID = 1L;


    private BigDecimal rid;

    private String name;

    private Integer age;

    private BigDecimal gender;

    private Boolean type;

    private String info;

    private BigDecimal status;

    private String account;

    private String password;

    private Integer amount;
}
