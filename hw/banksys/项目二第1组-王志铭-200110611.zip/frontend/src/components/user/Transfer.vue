<template>
    <div>
        <div style="margin-bottom: 5px;">
            <el-input v-model="rid" placeholder="请输入转出账号ID" suffix-icon="el-icon-search" style="width: 200px;"
                      @keyup.enter.native="loadPost"></el-input>
            <el-input v-model="rid2" placeholder="请输入转入账号ID" suffix-icon="el-icon-search" style="width: 200px;"
                      @keyup.enter.native="loadPost"></el-input>
            <el-button type="primary" style="margin-left: 5px;" @click="loadPost">搜索</el-button>
            <el-button type="success" @click="resetParam">重置</el-button>
            <el-button type="primary" style="margin-left: 5px;" @click="add">新增</el-button>
        </div>

        <el-table :data="tableData"
                  :header-cell-style="{ background: '#f2f5fc', color: '#555555' }"
                  border
        >
            <el-table-column prop="tid" label="转账编号" width="120">
            </el-table-column>
            <el-table-column prop="rid" label="转出账户ID" width="180">
            </el-table-column>
            <el-table-column prop="rid2" label="转入账户ID" width="180">
            </el-table-column>
            <el-table-column prop="rid" label="类型" width="90">
                <template slot-scope="scope">
                    <el-tag
                        :type="scope.row.rid == myid ? 'danger' : 'success'"
                        disable-transitions>{{(scope.row.rid == myid ? '转出' : '转入')}}</el-tag>
                </template>
            </el-table-column>
            <el-table-column prop="time" label="转账时间" width="180">
            </el-table-column>
            <el-table-column prop="amount" label="金额" width="90">
            </el-table-column>
        </el-table>

        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageNum"
                :page-sizes="[5, 10, 20,30]"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total">
        </el-pagination>

        <el-dialog
                title="提示"
                :visible.sync="centerDialogVisible"
                width="30%"
                center>

            <el-form ref="form" :rules="rules" :model="form" label-width="80px">
                <el-form-item label="转入账户" prop="rid2">
                    <el-col :span="20">
                        <el-input v-model="form.rid2"></el-input>
                    </el-col>
                </el-form-item>
                <el-form-item label="金额" prop="amount">
                    <el-col :span="20">
                        <el-input v-model="form.amount"></el-input>
                    </el-col>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="centerDialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="save">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
export default {
    name: "UserManage",
    data() {
        let checkRid2 =(rule,value,callback)=>{
            if(this.form.tid){
                return callback();
            }
            this.$axios.get(this.$httpUrl+"/register/findById?rid="+this.form.rid2).then(res=>res.data).then(res=>{
                if(res.code==200){
                    callback()
                }else{
                    callback(new Error('转入账户不存在'));
                }
            })
        };
        let checkAmount =(rule,value,callback)=>{
            this.$axios.get(this.$httpUrl+"/transfer/testAmount?rid="+this.form.rid+"&amount="+this.form.amount).then(res=>res.data).then(res=>{
                if(res.code==200){
                    callback()
                }else{
                    callback(new Error('转出账户金额不足'));
                }
            })
        };

        return {
            tableData: [],
            pageSize:10,
            pageNum:1,
            total:0,
            rid:'',
            rid2:'',
            myid:'',
            sexs:[
                {
                    value: '1',
                    label: '男'
                }, {
                    value: '0',
                    label: '女'
                }
            ],
            centerDialogVisible:false,
            form:{
                tid:'',
                rid:'',
                rid2:'',
                time:'',
                amount:'',
                type:'0',
            },
            rules: {
                rid2: [
                    {required: true, message: '请输入转出账户ID', trigger: 'blur'},
                    {validator:checkRid2,trigger: 'blur'}
                ],
                amount: [
                    {required: true, message: '请输入转账金额', trigger: 'blur'},
                    {pattern: /^([1-9][0-9]*)$/,message: '转账金额必须为正整数字',trigger: "blur"},
                    {validator:checkAmount,trigger: 'blur'}
                ],
            }
        }
    },
    methods:{
        resetForm() {
            this.$refs.form.rid = null;
            this.$refs.form.resetFields();
        },
        add(){
            this.centerDialogVisible = true
            this.$nextTick(()=>{
                this.resetForm()
            })
        },
        doSave(){
            this.form.type = (this.form.type == '1')
            this.form.status = 1
            this.$axios.post(this.$httpUrl+'/transfer/save',this.form).then(res=>res.data).then(res=>{
                console.log(res)
                if(res.code==200){
                    this.$message({
                        message: '操作成功！',
                        type: 'success'
                    });
                    this.centerDialogVisible = false
                    this.loadPost()
                    this.resetForm()
                }else{
                    this.$message({
                        message: '操作失败！',
                        type: 'error'
                    });
                }

            })
        },
        save(){
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.doSave();
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });

        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
            this.pageNum=1
            this.pageSize=val
            this.loadPost()
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`);
            this.pageNum=val
            this.loadPost()
        },
        loadGet(){
            this.$axios.get(this.$httpUrl+'/transfer/list').then(res=>res.data).then(res=>{
                console.log(res)
            })
        },
        resetParam(){
            this.rid = ''
            this.rid2 = ''
            this.loadPost()
        },
        loadPost(){
            this.$axios.post(this.$httpUrl+'/transfer/listPageC1',{
                pageSize:this.pageSize,
                pageNum:this.pageNum,
                param:{
                    rid:this.rid,
                    rid2:this.rid2,
                    myid:this.myid,
                }
            }).then(res=>res.data).then(res=>{
                console.log(res)
                if(res.code===200){
                    this.tableData=res.data
                    this.total=res.total
                }else{
                    alert('获取数据失败')
                }
            })
        }
    },
    beforeMount() {
        //this.loadGet();
        this.myid= JSON.parse(sessionStorage.getItem('CurUser')).rid.toString()
        this.form.rid = this.myid
        this.loadPost()
    }
}
</script>

<style scoped>

</style>