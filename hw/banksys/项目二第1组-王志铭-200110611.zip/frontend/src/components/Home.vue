<template>
    <div style="text-align: center;background-color: #f1f1f3;height: 100%;padding: 0px;margin: 0px;">
        <h1 style="font-size: 50px;">{{'欢迎你！'+user.name}}</h1>
        <el-descriptions  title="个人中心" :column="2" size="40" border>
            <el-descriptions-item>
                <template slot="label">
                    <i class="el-icon-s-custom"></i>
                    账号
                </template>
                {{user.account}}
            </el-descriptions-item>
            <el-descriptions-item>
                <template slot="label">
                    <i class="el-icon-money"></i>
                    账户余额
                </template>
                {{user.amount?user.amount:"无"}}
            </el-descriptions-item>
            <el-descriptions-item>
                <template slot="label">
                    <i class="el-icon-location-outline"></i>
                    性别
                </template>
                <el-tag
                        :type="user.gender === 1 ? 'primary' : 'danger'"
                        disable-transitions><i :class="user.gender==1?'el-icon-male':'el-icon-female'"></i>{{user.gender==1?"男":"女"}}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item>
                <template slot="label">
                    <i class="el-icon-tickets"></i>
                    角色
                </template>
                <el-tag
                        type="success"
                        disable-transitions>{{this.userType=="manager"?"管理员":"用户"}}</el-tag>

            </el-descriptions-item>
        </el-descriptions>

        <DateUtils></DateUtils>
    </div>
</template>

<script>
    import DateUtils from "./DateUtils";
    export default {
        name: "Home",
        components: {DateUtils},
        data() {

            return {
                user:{},
                userType:'',
            }
        },
        computed:{

        },
        methods:{
            init(){
                this.user = JSON.parse(sessionStorage.getItem('CurUser'))
                this.userType = JSON.parse(sessionStorage.getItem('CurUserType'))
            }
        },
        created(){
            this.init()
        },
        beforeMount() {
            this.$axios.get(this.$httpUrl+"/register/findById?rid="+this.user.rid).then(res=>res.data).then(res=>{
                if(res.code==200){
                    console.log(res.data[0]);
                    this.user = res.data[0]
                    this.userType = this.user.type ? "manager" : "user";
                    console.log(this.userType)
                }
            })
        }
    }
</script>

<style scoped>
    .el-descriptions{
        width:90%;

        margin: 0 auto;
        text-align: center;
    }
</style>